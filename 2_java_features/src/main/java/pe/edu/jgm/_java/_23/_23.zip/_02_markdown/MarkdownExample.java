package pe.edu.jgm._java._23._02_markdown;

public class MarkdownExample {

    void main(){

    }

    /**
     * This method calculates the factorial of a number.
     * @param n the number to calculate the factorial for
     * @return the factorial of n
     */
    public static int factorial_1(int n) {
        // TODO
        return -1;
    }

    /// This method calculates the factorial of a number.

    /// Parameters:
    /// * `n`: the number to calculate the factorial for

    /// Returns:
    /// The factorial of n
    public static int factorial_2(int n) {
        // TODO
        return -1;
    }
}
