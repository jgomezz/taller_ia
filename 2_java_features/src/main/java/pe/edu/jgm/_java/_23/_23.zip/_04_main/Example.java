package pe.edu.jgm._java._23._04_main;

import static java.io.IO.*;

public class Example {

    void main() {
        println("Hello, World!");
    }

}
