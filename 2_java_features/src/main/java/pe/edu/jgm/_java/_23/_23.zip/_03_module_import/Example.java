package pe.edu.jgm._java._23._03_module_import;

//import java.util.ArrayList;
//import java.util.List;

import module java.base;

public class Example {

    void main(){
        List<String> myList = new ArrayList<>();
    }


}
